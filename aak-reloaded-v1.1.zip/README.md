
# Anti-Adblock Killer Reloaded (AAK-R)

A modern revival of the original Anti-Adblock Killer by Reek. This script and filter list help you bypass anti-adblock popups and warnings on websites.

## Components

- **User Script**: JavaScript loaded via Tampermonkey/Greasemonkey.
- **Filter List**: Compatible with uBlock Origin and AdGuard.

## Installation

1. Install the [user script](./user-script/anti-adblock-killer.user.js) via Tampermonkey.
2. Add the filter list [aak-filters.txt](./filters/aak-filters.txt) to uBlock Origin.

## License

[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
