// ==UserScript==
// @name         Anti-Adblock Killer Reloaded
// @namespace    https://github.com/AbdulrahmanDev/aak-reloaded
// @version      1.1.0
// @description  Bypass anti-adblock mechanisms and keep your ad blocker running. Modern revival of Reek's original script.
// @author       Abdulrahman
// @match        *://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    const keywords = [
        'disable adblock', 'turn off adblock', 'disable your ad blocker',
        'ad blocker detected', 'please disable adblock', 'we noticed you're using an ad blocker',
        'turn off your adblocker', 'disable your adblocker', 'ads help us run this site'
    ];

    const keywordRegex = new RegExp(keywords.join('|'), 'i');

    const removeNode = (node) => {
        if (!node || node.nodeType !== 1) return;
        const text = node.textContent || "";
        if (keywordRegex.test(text)) {
            console.log("[AAK-R] Removing node:", node);
            node.remove();
        }
    };

    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            mutation.addedNodes.forEach(removeNode);
        }
    });

    const stealthRemoveAds = () => {
        const all = document.querySelectorAll('div, section, article, aside');
        for (const el of all) {
            const style = window.getComputedStyle(el);
            const txt = el.innerText.toLowerCase();
            if (
                style.position === 'fixed' || style.position === 'absolute' ||
                style.zIndex > 1000 || txt.length < 300
            ) {
                if (keywordRegex.test(txt)) {
                    el.remove();
                    console.log("[AAK-R] Stealth removed:", el);
                }
            }
        }
    };

    window.addEventListener('DOMContentLoaded', stealthRemoveAds);
    window.setInterval(stealthRemoveAds, 5000);

    const initObserver = () => {
        try {
            observer.observe(document.body, { childList: true, subtree: true });
            console.log("[AAK-R] MutationObserver started.");
        } catch (err) {
            console.warn("[AAK-R] Failed to init observer:", err);
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initObserver);
    } else {
        initObserver();
    }
})();
